﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JavitoVizsga0826
{
    class Metodusok
    {
        
        public static void Feltolt (string[] vizsgalatok, int[] eletkorok, string[] varosreszek, bool[] fertozottek)
        {
            Random RND = new Random();
            for (int i = 0; i < vizsgalatok.Length; i++)
            {
                int eletkor = RND.Next(25, 91);
                int fertozott = RND.Next(1, 101);
                int varosresz = RND.Next(1, 101);
                vizsgalatok[i] = (i + 1) + ". vizsgálat";
                eletkorok[i] = eletkor;
                if (varosresz % 2 == 0)
                {
                    varosreszek[i] = "Pest";
                }
                else
                {
                    varosreszek[i] = "Buda";
                }
                fertozottek[i] = fertozott % 2 == 0;
            }
        }
        public static void Kiir (string[] vizsgalatok, int[] eletkorok, string[] varosreszek, bool[] fertozottek)
        {
            for (int i = 0; i < vizsgalatok.Length; i++)
            {
                Console.WriteLine(vizsgalatok[i] + " " + eletkorok[i] + " " + varosreszek[i] + " " + fertozottek[i]);
            }
        }
    }
}
