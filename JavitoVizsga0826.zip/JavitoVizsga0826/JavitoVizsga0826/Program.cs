﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JavitoVizsga0826
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] vizsgalatok = new string[100];
            int[] eletkorok = new int[100];
            string[] varosreszek = new string[100];
            bool[] fertozottek = new bool[100];
            Metodusok.Feltolt(vizsgalatok, eletkorok, varosreszek, fertozottek);
            Console.ReadLine();
            
        }
    }
}
